import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import axios from 'axios'

// axios.get('http://localhost:3001/notes').then(response=>{
//   const notes=response.data
//   console.log(notes)
//   createRoot(document.getElementById('root')).render(<App notes={notes}/>)
// })

// //console.log(promise)

// const promise2 = axios.get('http://localhost:3001/foobar')
// console.log(promise2)
// const notes = [
//   {
//     id: 1,
//     content: 'HTML is easy',
//     important: true,
//   },
//   {
//     id: 2,
//     content: 'Browser can execute only JavaScript',
//     important: false,
//   },
//   {
//     id: 3,
//     content: 'GET and POST are the most important methods of HTTP protocol',
//     important: true,
//   },
// ]

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
