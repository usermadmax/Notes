import { useState, useEffect } from 'react'
import axios from 'axios'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Notes from './Notes'

// const Course=({course})=>
// {
//   let total=0
//   for(let p of course.parts)
//   {
//     total+=p.exercises;
//   }
//   return (
//     <div>
//       <h3>
//         {course.name}
//       </h3>
//       <ul> {course.parts.map(part=>
//         (
//           <li key={part.id}>
//            {part.name} -{part.exercises}
//           </li>
//         )
//       )}
//       </ul>
//      <p><strong>Total {total}</strong></p>
//     </div>
//   )
// }

const App = () => {
   const [notes, setNotes] = useState([])
    const [showAll, setShowAll] = useState(true)
  const [note,setNote]=useState(notes)
  useEffect(() => {
    console.log('effect')
    axios
      .get('http://localhost:3001/notes')
      .then(response => {
        console.log('promise fulfilled')
        setNotes(response.data)
      })
  }, [])
  console.log('render', notes.length, 'notes')
    const addNote = (event) => {
    event.preventDefault()
  const noteObject = {
    content: newNote,
    important: Math.random() < 0.5,
  }

  axios
    .post('http://localhost:3001/notes/', noteObject)
    .then(response => {
      setNotes(notes.concat(response.data))
      setNewNote('')
    })
}
    const [newNote, setNewNote] = useState(
    ' new note ..'
  ) 
    const handleNoteChange = (event) => {
    console.log(event.target.value)
    setNewNote(event.target.value)
  }
   const notesToShow = showAll
    ? notes
    : notes.filter(note => note.important)

     const toggleImportanceOf = (id) => {
    console.log('importance of ' + id + ' needs to be toggled')
  }
  return (
    <div>
      <h1>Notes</h1>
          <div>More actions
        <button onClick={() => setShowAll(!showAll)}>
          show {showAll ? 'important' : 'all'}
        </button>
      </div>
      <ul>
        {
          notesToShow.map((note)=>(
        <Notes key={note.id}  note={note} toggleImportance={() => toggleImportanceOf(note.id)}/>
          ))
        }
      </ul>
      <form onSubmit={addNote}>
      <input  value={newNote} onChange={handleNoteChange} />
      <button type="submit">Save</button>
      </form>
    </div>
  )
}



// const App = () => {
//   const [good, setGood] = useState(0)
//   const [neutral, setNeutral] = useState(0)
//   const [bad, setBad] = useState(0)

//   const all= good+bad+neutral
//   const avg=all==0 ? 0 : (good-bad)/all
//   const btngood = () => {
//     setGood(good+1)

//   }
//    const btnneutral = () => {
//     setNeutral(neutral+1)
//   }
//    const btnbad = () => {
//     setBad( bad+1)
//   }
//   return (
//     <div>

//       <h1>
//         Give Feedback
//       </h1>
//       <button onClick={btngood}>
//         Good
//       </button>
//       <button onClick={btnneutral}>
//         Neutral
//       </button>
//       <button onClick={btnbad}>
//         Bad
//       </button>
//       <h2>
//         Statistics
//       </h2>
//       <h5>
//         good {good}
//       </h5>
//       <h5>
//         neutral {neutral}
//       </h5>
//       <h5>
//         bad {bad}
//       </h5>
//       <h5>
//         all {all}
//       </h5>
//       <h5>
//         Average {avg}
//       </h5>

//     </div>
//   )


// }


export default App;
